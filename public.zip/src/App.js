import logo from './logo.svg';
import TicTacApp from './tic_comps/ticTacApp';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>React work</h1>
      <TicTacApp />
    </div>
  );
}

export default App;
