import React from 'react';
import Tile from './tile';

function Board(props){
  return(
    <div className="board mx-auto row">
      <Tile />
      <Tile />
      <Tile />
      <Tile />
      <Tile />
      <Tile />
      <Tile />
      <Tile />
      <Tile />
    </div> 
  )
}

export default Board