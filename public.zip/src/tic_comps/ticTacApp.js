import React from 'react';
import Board from './board';

function TicTacApp(props){
  return(
    <div className="container">
      <Board />
    </div> 
  )
}

export default TicTacApp